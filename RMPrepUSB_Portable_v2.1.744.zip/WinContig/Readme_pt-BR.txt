***********************************************************
WinContig 2.2.0.0
Copyright � 2006-2017 Marco D'Amato
Web: http://wincontig.mdtzone.it/en/index.htm
E-mail: md@mdtzone.it
***********************************************************
 
WinContig � uma ferramenta de desfragmenta��o stand-alone f�cil de usar que n�o cria qualquer diret�rio de instala��o ou entradas no Registro no seu computador. Sua finalidade � a desfragmenta��o r�pida de arquivos sem a necessidade de desfragmentar o disco inteiro. Al�m disso, WinContig permite agrupar arquivos em perfis, e tamb�m aceita um grande n�mero de op��es em linha de comando opcionais que voc� pode usar para controlar a forma como utiliza o programa.

WinContig � uma aplica��o designada para os sistemas operacionais Windows XP, Windows Vista, Windows Seven, Windows 8/8.1, Windows 10. 

Como um usu�rio do Windows XP, Windows Vista, Windows Seven, Windows 8/8.1 ou Windows 10 voc� deve estar logado em uma conta com todos os direitos de administrador.


==================================================================== 
Licen�a
====================================================================
WinContig � lan�ado como freeware para uso pessoal e comercial.


====================================================================
Acordo de Licen�a do Usu�rio Final
====================================================================
Este software e todos os arquivos que o acompanham s�o fornecidos pelo autor "como est�" e sem quaisquer garantias expressas ou impl�citas, incluindo, mas n�o limitado a, as garantias impl�citas de comercializa��o e adequa��o para um prop�sito particular. Em nenhum caso, o autor ser� respons�vel por quaisquer danos (incluindo, sem limita��o, danos por perda de lucros, perda de uso ou de dados, interrup��o de neg�cios, perda de informa��es comerciais, ou qualquer outra perda pecuni�ria)  derivantes ou correlacionados do uso ou incapacidade de usar este produto, mesmo que o autor tenha sido avisado da eventualidade de verificarem-se tais danos. O usu�rio assume expressamente a inteira responsabilidade e os riscos pelo uso deste produto de software e sua documenta��o.

As informa��es contidas neste documento est�o sujeitas a altera��o sem aviso pr�vio e n�o representam um compromisso por parte do autor. O software descrito neste documento � fornecido sob este contrato de licen�a.

A utiliza��o deste produto para qualquer per�odo de tempo constitui a sua aceita��o deste contrato e sujeita-o aos seus conte�dos.


==================================================================== 
Instala��o
====================================================================
WinContig � um execut�vel aut�nomo e n�o requer qualquer processo de instala��o ou DLLs adicionais. Para come�ar a us�-lo, basta fazer o download, extrair o conte�do do arquivo ZIP para qualquer pasta que voc� desejar, e execut�-lo.


==================================================================== 
Coment�rios
====================================================================
Se voc� tiver sugest�es, coment�rios, ou encontrou algum problema no WinContig, por favor envie uma mensagem para support@mdtzone.it


====================================================================
Reconhecimento de Direitos Autorais e Marcas Comerciais
====================================================================
Windows, Windows XP, Windows Vista, Windows Seven, Windows 8, Windows 8.1 and Windows 10 s�o marcas registradas da Microsoft Corporation. Todas as outras marcas comerciais s�o propriedade de seus respectivos propriet�rios.